// //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  // //

// works as a generic!
Array.sg_asyncEach([1, 2, 3],
	function(value, key, array) {
		console.log(value, key, array)
		return "eachFn result " + value
	},
	function(err, result) {
		console.log('sg_asyncEach callback', err && "Error!" || "Success!", result)
	}
)

// works as a method!
;[1, 2, 3].sg_asyncEach(
	function(value, key, array) {
		console.log(value, key, array)
		return "eachFn result " + value
	},
	function(err, result) {
		console.log('sg_asyncEach callback', err && "Error!" || "Success!", result)
	}
)

// error handling!
Array.sg_asyncEach([1, 2, 3]
	,function(){throw new Error("FAIL on purpose!")}
	,function(err){if (err) throw err}
)

// Works on objects and arrays!
Object.sg_asyncEach({a:'a', b:'b', c:'c'},
	function(value, key, array) {
		console.log(value, key, array)
		return "eachFn result " + value
	},
	function(err, result) {
		console.log('sg_asyncEach callback', err && "Error!" || "Success!", result)
	}
)

// //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  //  // //

// Works on MooTools Elements collections if MooTools is in your environment!
if (typeof $$ != 'undefined'){

	new Element('div', {html:"<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol<p>Lol"})
	.inject(document.body)

	$$('p')
	.setStyle('color', '#f00')
	.sg_asyncEach(
		function(el, i, elements) {
			window.T = window.T || +new Date
			el.setStyle('color', '#0f0')
			return el
		},
		function(err, el) {
			el.appendText(' sg_asyncEach:' + (new Date - window.T) + 'ms')
		}
	)

}
